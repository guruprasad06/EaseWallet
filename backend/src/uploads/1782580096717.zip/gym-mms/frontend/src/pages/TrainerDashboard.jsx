import { useEffect, useState } from 'react';
import api from '../api/client.js';

export default function TrainerDashboard() {
  const [members, setMembers] = useState([]);
  const [form, setForm] = useState({ memberId: '', title: '', difficulty: 'beginner', exercises: '' });
  const [msg, setMsg] = useState(null);

  useEffect(() => { api.get('/trainers/members').then((r) => setMembers(r.data.members)); }, []);

  const submit = async (e) => {
    e.preventDefault();
    try {
      const exercises = form.exercises.split('\n').filter(Boolean).map((line) => {
        const [name, sets, reps] = line.split('|').map((s) => s.trim());
        return { name, sets: Number(sets) || 3, reps: Number(reps) || 10 };
      });
      await api.post('/workouts', {
        memberId: form.memberId,
        title: form.title,
        difficulty: form.difficulty,
        exercises,
        schedule: { days: ['Mon', 'Wed', 'Fri'], time: '07:00' },
      });
      setMsg({ type: 'ok', text: 'Workout created' });
      setForm({ memberId: '', title: '', difficulty: 'beginner', exercises: '' });
    } catch (e) {
      setMsg({ type: 'err', text: e.response?.data?.message || 'Failed' });
    }
  };

  return (
    <>
      <h1>Trainer Dashboard</h1>
      {msg && <div className={`alert ${msg.type}`}>{msg.text}</div>}

      <div className="card">
        <h2>Assigned Members</h2>
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Phone</th></tr></thead>
          <tbody>
            {members.map((m) => <tr key={m._id}><td>{m.name}</td><td>{m.email}</td><td>{m.phone || '—'}</td></tr>)}
            {!members.length && <tr><td colSpan="3" className="muted">No members assigned</td></tr>}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h2>Create Workout Plan</h2>
        <form onSubmit={submit}>
          <div className="form-row"><label>Member</label>
            <select required value={form.memberId} onChange={(e) => setForm({ ...form, memberId: e.target.value })}>
              <option value="">Select member…</option>
              {members.map((m) => <option key={m._id} value={m._id}>{m.name}</option>)}
            </select></div>
          <div className="form-row"><label>Title</label>
            <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} /></div>
          <div className="form-row"><label>Difficulty</label>
            <select value={form.difficulty} onChange={(e) => setForm({ ...form, difficulty: e.target.value })}>
              <option>beginner</option><option>intermediate</option><option>advanced</option>
            </select></div>
          <div className="form-row"><label>Exercises (one per line: name | sets | reps)</label>
            <textarea rows="5" value={form.exercises} onChange={(e) => setForm({ ...form, exercises: e.target.value })}
              placeholder="Bench Press | 4 | 8&#10;Squats | 4 | 10" /></div>
          <button className="btn">Create</button>
        </form>
      </div>
    </>
  );
}
