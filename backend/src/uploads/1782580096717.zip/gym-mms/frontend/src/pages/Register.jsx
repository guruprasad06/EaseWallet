import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Register() {
  const { register } = useAuth();
  const nav = useNavigate();
  const [form, setForm] = useState({ name: '', email: '', password: '', role: 'member' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setErr(''); setBusy(true);
    try {
      await register(form);
      nav('/dashboard');
    } catch (e) {
      setErr(e.response?.data?.message || 'Registration failed');
    } finally { setBusy(false); }
  };

  return (
    <div className="auth-wrap">
      <div className="card">
        <h1>Create account</h1>
        <p className="muted" style={{ marginBottom: 20 }}>Join the gym today</p>
        {err && <div className="alert err">{err}</div>}
        <form onSubmit={submit}>
          <div className="form-row"><label>Name</label>
            <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} /></div>
          <div className="form-row"><label>Email</label>
            <input type="email" required value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })} /></div>
          <div className="form-row"><label>Password</label>
            <input type="password" required minLength={6} value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })} /></div>
          <div className="form-row"><label>Role</label>
            <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value })}>
              <option value="member">Member</option>
              <option value="trainer">Trainer</option>
            </select></div>
          <button className="btn" disabled={busy}>{busy ? 'Creating…' : 'Sign Up'}</button>
        </form>
        <p className="muted" style={{ marginTop: 18 }}>Already have an account? <Link to="/login">Login</Link></p>
      </div>
    </div>
  );
}
