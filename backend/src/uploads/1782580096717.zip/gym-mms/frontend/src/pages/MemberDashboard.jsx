import { useEffect, useState } from 'react';
import api from '../api/client.js';

export default function MemberDashboard() {
  const [membership, setMembership] = useState(null);
  const [attendance, setAttendance] = useState([]);
  const [workouts, setWorkouts] = useState([]);
  const [msg, setMsg] = useState(null);

  const load = async () => {
    const [m, a, w] = await Promise.all([
      api.get('/memberships/me'),
      api.get('/attendance/me'),
      api.get('/workouts/me'),
    ]);
    setMembership(m.data.membership);
    setAttendance(a.data.items);
    setWorkouts(w.data.workouts);
  };
  useEffect(() => { load(); }, []);

  const action = async (path) => {
    try {
      await api.post(path);
      setMsg({ type: 'ok', text: 'Done!' });
      load();
    } catch (e) {
      setMsg({ type: 'err', text: e.response?.data?.message || 'Failed' });
    }
  };

  return (
    <>
      <h1>Member Dashboard</h1>
      {msg && <div className={`alert ${msg.type}`}>{msg.text}</div>}

      <div className="card">
        <h2>My Membership</h2>
        {membership ? (
          <div className="flex-between">
            <div>
              <p><strong>{membership.plan?.name}</strong> · ₹{membership.plan?.price?.amount}</p>
              <p className="muted">Expires: {new Date(membership.expiryDate).toLocaleDateString()}</p>
              <span className={`badge ${membership.status === 'active' ? 'active' : 'expired'}`}>{membership.status}</span>
            </div>
            <button className="btn ghost" onClick={() => api.post('/memberships/renew').then(load)}>Renew</button>
          </div>
        ) : <p className="muted">No active membership. Visit Plans to subscribe.</p>}
      </div>

      <div className="card">
        <div className="flex-between" style={{ marginBottom: 14 }}>
          <h2>Today's Attendance</h2>
          <div>
            <button className="btn ok" onClick={() => action('/attendance/checkin')} style={{ marginRight: 8 }}>Check In</button>
            <button className="btn ghost" onClick={() => action('/attendance/checkout')}>Check Out</button>
          </div>
        </div>
        <h3 style={{ marginTop: 18 }}>History</h3>
        <table>
          <thead><tr><th>Date</th><th>Check In</th><th>Check Out</th></tr></thead>
          <tbody>
            {attendance.map((a) => (
              <tr key={a._id}>
                <td>{a.date}</td>
                <td>{new Date(a.checkIn).toLocaleTimeString()}</td>
                <td>{a.checkOut ? new Date(a.checkOut).toLocaleTimeString() : '—'}</td>
              </tr>
            ))}
            {!attendance.length && <tr><td colSpan="3" className="muted">No attendance yet</td></tr>}
          </tbody>
        </table>
      </div>

      <div className="card">
        <h2>My Workouts</h2>
        {workouts.length ? workouts.map((w) => (
          <div key={w._id} style={{ padding: '12px 0', borderBottom: '1px solid var(--border)' }}>
            <div className="flex-between">
              <strong>{w.title}</strong>
              <span className="tag">{w.difficulty}</span>
            </div>
            <p className="muted" style={{ fontSize: 13 }}>by {w.trainer?.name} · {w.schedule?.days?.join(', ')} {w.schedule?.time}</p>
            <ul style={{ marginTop: 6, paddingLeft: 18 }}>
              {w.exercises?.map((e, i) => <li key={i} className="muted">{e.name} — {e.sets}×{e.reps}</li>)}
            </ul>
          </div>
        )) : <p className="muted">No workouts assigned yet.</p>}
      </div>
    </>
  );
}
