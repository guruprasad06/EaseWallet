import { useEffect, useState } from 'react';
import api from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Plans() {
  const [plans, setPlans] = useState([]);
  const [msg, setMsg] = useState(null);
  const { user } = useAuth();

  useEffect(() => { api.get('/plans').then((r) => setPlans(r.data.plans)); }, []);

  const subscribe = async (planId) => {
    try {
      await api.post('/memberships/subscribe', { planId });
      setMsg({ type: 'ok', text: 'Subscribed successfully!' });
    } catch (e) {
      setMsg({ type: 'err', text: e.response?.data?.message || 'Failed' });
    }
  };

  return (
    <>
      <h1>Membership Plans</h1>
      <p className="muted" style={{ marginBottom: 20 }}>Choose a plan that fits your fitness journey</p>
      {msg && <div className={`alert ${msg.type}`}>{msg.text}</div>}
      <div className="grid">
        {plans.map((p) => (
          <div key={p._id} className="card">
            <h2>{p.name}</h2>
            <p style={{ fontSize: 28, fontWeight: 800, color: 'var(--accent)', margin: '8px 0' }}>
              ₹{p.price.amount}
              <span className="muted" style={{ fontSize: 13, fontWeight: 400 }}> / {p.durationDays}d</span>
            </p>
            <ul style={{ listStyle: 'none', margin: '12px 0' }}>
              {p.features.map((f, i) => <li key={i} className="muted" style={{ padding: '4px 0' }}>✓ {f}</li>)}
            </ul>
            {user?.role === 'member' && (
              <button className="btn" onClick={() => subscribe(p._id)}>Subscribe</button>
            )}
          </div>
        ))}
      </div>
    </>
  );
}
