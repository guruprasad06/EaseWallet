import { useEffect, useState } from 'react';
import api from '../api/client.js';

export default function AdminDashboard() {
  const [users, setUsers] = useState([]);
  const [trainers, setTrainers] = useState([]);
  const [report, setReport] = useState(null);
  const [roleFilter, setRoleFilter] = useState('');

  const load = async () => {
    const [u, t, r] = await Promise.all([
      api.get('/admin/users' + (roleFilter ? `?role=${roleFilter}` : '')),
      api.get('/admin/users?role=trainer'),
      api.get('/admin/reports/subscriptions'),
    ]);
    setUsers(u.data.users);
    setTrainers(t.data.users);
    setReport(r.data);
  };
  useEffect(() => { load(); }, [roleFilter]);

  const toggleBlock = async (id) => { await api.patch(`/admin/users/${id}/block`); load(); };
  const assign = async (id, trainerId) => {
    if (!trainerId) return;
    await api.patch(`/admin/users/${id}/assign-trainer`, { trainerId });
    load();
  };

  return (
    <>
      <h1>Admin Dashboard</h1>

      <div className="grid">
        <div className="card">
          <h3>Total Revenue</h3>
          <p style={{ fontSize: 28, fontWeight: 800, color: 'var(--ok)' }}>₹{report?.totalRevenue || 0}</p>
        </div>
        {report?.statusBreakdown?.map((s) => (
          <div key={s._id} className="card">
            <h3>{s._id} memberships</h3>
            <p style={{ fontSize: 28, fontWeight: 800 }}>{s.count}</p>
          </div>
        ))}
      </div>

      <div className="card">
        <div className="flex-between" style={{ marginBottom: 14 }}>
          <h2>Users</h2>
          <select style={{ width: 200 }} value={roleFilter} onChange={(e) => setRoleFilter(e.target.value)}>
            <option value="">All roles</option>
            <option value="member">Members</option>
            <option value="trainer">Trainers</option>
            <option value="admin">Admins</option>
          </select>
        </div>
        <table>
          <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Assign Trainer</th><th></th></tr></thead>
          <tbody>
            {users.map((u) => (
              <tr key={u._id}>
                <td>{u.name}</td>
                <td>{u.email}</td>
                <td><span className="badge role">{u.role}</span></td>
                <td><span className={`badge ${u.isBlocked ? 'expired' : 'active'}`}>{u.isBlocked ? 'blocked' : 'active'}</span></td>
                <td>
                  {u.role === 'member' ? (
                    <select defaultValue={u.assignedTrainer || ''} onChange={(e) => assign(u._id, e.target.value)}>
                      <option value="">—</option>
                      {trainers.map((t) => <option key={t._id} value={t._id}>{t.name}</option>)}
                    </select>
                  ) : <span className="muted">—</span>}
                </td>
                <td>
                  <button className="btn ghost" onClick={() => toggleBlock(u._id)}>
                    {u.isBlocked ? 'Unblock' : 'Block'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
