import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <>
      <div className="hero">
        <h1>Build Your <span>Strongest</span> Self.</h1>
        <p>A complete gym membership platform — manage your plan, track attendance, and crush workouts with assigned trainers.</p>
        <Link to="/register"><button className="btn">Get Started</button></Link>
      </div>
      <div className="grid">
        <div className="card"><h3>🏋️ Flexible Plans</h3><p className="muted">Monthly, quarterly, and yearly memberships built around your goals.</p></div>
        <div className="card"><h3>📊 Track Progress</h3><p className="muted">Check-in daily and review your monthly attendance history.</p></div>
        <div className="card"><h3>👨‍🏫 Personal Trainers</h3><p className="muted">Get assigned a trainer who builds workout plans tailored to you.</p></div>
        <div className="card"><h3>🔒 Secure & Private</h3><p className="muted">JWT-secured backend with role-based access control.</p></div>
      </div>
    </>
  );
}
