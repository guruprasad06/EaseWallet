import { Routes, Route, Navigate, Link, useNavigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext.jsx';
import Home from './pages/Home.jsx';
import Login from './pages/Login.jsx';
import Register from './pages/Register.jsx';
import Plans from './pages/Plans.jsx';
import MemberDashboard from './pages/MemberDashboard.jsx';
import TrainerDashboard from './pages/TrainerDashboard.jsx';
import AdminDashboard from './pages/AdminDashboard.jsx';

function Nav() {
  const { user, logout } = useAuth();
  const nav = useNavigate();
  return (
    <nav className="nav">
      <Link to="/" className="brand">💪 IRONHOUSE</Link>
      <div className="links">
        <Link to="/">Home</Link>
        <Link to="/plans">Plans</Link>
        {user && <Link to="/dashboard">Dashboard</Link>}
        {!user ? (
          <>
            <Link to="/login">Login</Link>
            <Link to="/register"><button className="btn">Join Now</button></Link>
          </>
        ) : (
          <>
            <span className="muted">{user.name} <span className="badge role">{user.role}</span></span>
            <button className="btn ghost" onClick={async () => { await logout(); nav('/'); }}>Logout</button>
          </>
        )}
      </div>
    </nav>
  );
}

function Dashboard() {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  if (user.role === 'admin') return <AdminDashboard />;
  if (user.role === 'trainer') return <TrainerDashboard />;
  return <MemberDashboard />;
}

export default function App() {
  const { loading } = useAuth();
  if (loading) return <div className="container">Loading…</div>;
  return (
    <>
      <Nav />
      <div className="container">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/plans" element={<Plans />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </div>
    </>
  );
}
