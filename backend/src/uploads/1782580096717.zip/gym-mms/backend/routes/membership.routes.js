const r = require('express').Router();
const c = require('../controllers/membership.controller');
const { requireAuth, requireRole } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { subscribeSchema } = require('../validators/schemas');

r.post('/subscribe', requireAuth, requireRole('member'), validate(subscribeSchema), c.subscribe);
r.post('/renew', requireAuth, requireRole('member'), c.renew);
r.get('/me', requireAuth, requireRole('member'), c.mine);

module.exports = r;
