const r = require('express').Router();
const c = require('../controllers/admin.controller');
const { requireAuth, requireRole } = require('../middleware/auth');

r.get('/users', requireAuth, requireRole('admin'), c.listUsers);
r.patch('/users/:id/block', requireAuth, requireRole('admin'), c.toggleBlock);
r.patch('/users/:id/assign-trainer', requireAuth, requireRole('admin'), c.assignTrainer);
r.get('/reports/subscriptions', requireAuth, requireRole('admin'), c.subscriptionsReport);

module.exports = r;
