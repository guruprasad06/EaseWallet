const r = require('express').Router();
const c = require('../controllers/trainer.controller');
const { requireAuth, requireRole } = require('../middleware/auth');

r.get('/members', requireAuth, requireRole('trainer'), c.myMembers);

module.exports = r;
