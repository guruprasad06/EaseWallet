const r = require('express').Router();
const c = require('../controllers/plan.controller');
const { requireAuth, requireRole } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { planSchema } = require('../validators/schemas');

r.get('/', c.list);
r.post('/', requireAuth, requireRole('admin'), validate(planSchema), c.create);
r.put('/:id', requireAuth, requireRole('admin'), c.update);
r.delete('/:id', requireAuth, requireRole('admin'), c.remove);

module.exports = r;
