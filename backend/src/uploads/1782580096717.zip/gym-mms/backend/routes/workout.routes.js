const r = require('express').Router();
const c = require('../controllers/workout.controller');
const { requireAuth, requireRole } = require('../middleware/auth');
const validate = require('../middleware/validate');
const { workoutSchema } = require('../validators/schemas');

r.post('/', requireAuth, requireRole('trainer', 'admin'), validate(workoutSchema), c.create);
r.put('/:id', requireAuth, requireRole('trainer', 'admin'), c.update);
r.get('/me', requireAuth, requireRole('member'), c.mine);
r.get('/member/:memberId', requireAuth, requireRole('trainer', 'admin'), c.forMember);

module.exports = r;
