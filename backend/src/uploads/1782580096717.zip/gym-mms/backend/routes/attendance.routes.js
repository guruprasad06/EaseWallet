const r = require('express').Router();
const c = require('../controllers/attendance.controller');
const { requireAuth, requireRole } = require('../middleware/auth');

r.post('/checkin', requireAuth, requireRole('member'), c.checkIn);
r.post('/checkout', requireAuth, requireRole('member'), c.checkOut);
r.get('/me', requireAuth, requireRole('member'), c.history);
r.get('/report/monthly', requireAuth, requireRole('admin', 'trainer'), c.monthlyReport);
r.get('/active', requireAuth, requireRole('admin'), c.active);

module.exports = r;
