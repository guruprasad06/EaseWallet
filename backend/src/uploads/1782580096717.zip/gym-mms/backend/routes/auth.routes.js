const r = require('express').Router();
const c = require('../controllers/auth.controller');
const validate = require('../middleware/validate');
const { registerSchema, loginSchema } = require('../validators/schemas');
const { requireAuth } = require('../middleware/auth');

r.post('/register', validate(registerSchema), c.register);
r.post('/login', validate(loginSchema), c.login);
r.post('/refresh', c.refresh);
r.post('/logout', c.logout);
r.get('/me', requireAuth, c.me);

module.exports = r;
