const Joi = require('joi');

exports.registerSchema = Joi.object({
  name: Joi.string().min(2).max(80).required(),
  email: Joi.string().email().required(),
  password: Joi.string().min(6).max(128).required(),
  role: Joi.string().valid('admin', 'trainer', 'member'),
  phone: Joi.string().allow(''),
});

exports.loginSchema = Joi.object({
  email: Joi.string().email().required(),
  password: Joi.string().required(),
});

exports.planSchema = Joi.object({
  name: Joi.string().required(),
  price: Joi.object({
    amount: Joi.number().min(0).required(),
    currency: Joi.string().default('INR'),
  }).required(),
  durationDays: Joi.number().integer().min(1).required(),
  features: Joi.array().items(Joi.string()),
  status: Joi.string().valid('active', 'inactive'),
});

exports.subscribeSchema = Joi.object({
  planId: Joi.string().hex().length(24).required(),
});

exports.workoutSchema = Joi.object({
  memberId: Joi.string().hex().length(24).required(),
  title: Joi.string().required(),
  exercises: Joi.array().items(
    Joi.object({
      name: Joi.string().required(),
      sets: Joi.number().integer().min(1),
      reps: Joi.number().integer().min(1),
      notes: Joi.string().allow(''),
    })
  ),
  schedule: Joi.object({
    days: Joi.array().items(Joi.string().valid('Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun')),
    time: Joi.string(),
  }),
  difficulty: Joi.string().valid('beginner', 'intermediate', 'advanced'),
});
