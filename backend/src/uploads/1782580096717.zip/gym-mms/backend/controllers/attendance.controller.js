const Attendance = require('../models/Attendance');
const Membership = require('../models/Membership');
const mongoose = require('mongoose');

const today = () => new Date().toISOString().slice(0, 10);

exports.checkIn = async (req, res) => {
  const m = await Membership.findOne({ member: req.user._id });
  if (!m || m.expiryDate < new Date()) {
    return res.status(403).json({ message: 'Active membership required' });
  }
  try {
    const a = await Attendance.create({
      member: req.user._id,
      date: today(),
      checkIn: new Date(),
    });
    res.status(201).json({ attendance: a });
  } catch (e) {
    if (e.code === 11000) return res.status(409).json({ message: 'Already checked in today' });
    throw e;
  }
};

exports.checkOut = async (req, res) => {
  const a = await Attendance.findOne({ member: req.user._id, date: today() });
  if (!a) return res.status(404).json({ message: 'No check-in for today' });
  if (a.checkOut) return res.status(409).json({ message: 'Already checked out' });
  a.checkOut = new Date();
  await a.save();
  res.json({ attendance: a });
};

exports.history = async (req, res) => {
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(100, parseInt(req.query.limit) || 20);
  const [items, total] = await Promise.all([
    Attendance.find({ member: req.user._id })
      .sort({ date: -1 })
      .skip((page - 1) * limit)
      .limit(limit),
    Attendance.countDocuments({ member: req.user._id }),
  ]);
  res.json({ items, total, page, pages: Math.ceil(total / limit) });
};

exports.monthlyReport = async (req, res) => {
  const month = parseInt(req.query.month) || new Date().getMonth() + 1;
  const year = parseInt(req.query.year) || new Date().getFullYear();
  const start = `${year}-${String(month).padStart(2, '0')}-01`;
  const endDate = new Date(year, month, 0).toISOString().slice(0, 10);

  const data = await Attendance.aggregate([
    { $match: { date: { $gte: start, $lte: endDate } } },
    {
      $group: {
        _id: '$member',
        days: { $sum: 1 },
      },
    },
    {
      $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'member' },
    },
    { $unwind: '$member' },
    {
      $project: {
        memberId: '$_id',
        days: 1,
        name: '$member.name',
        email: '$member.email',
        _id: 0,
      },
    },
    { $sort: { days: -1 } },
  ]);

  res.json({ month, year, report: data });
};

exports.active = async (req, res) => {
  // members who checked in in the last 7 days
  const cutoff = new Date();
  cutoff.setDate(cutoff.getDate() - 7);
  const cutoffStr = cutoff.toISOString().slice(0, 10);
  const data = await Attendance.aggregate([
    { $match: { date: { $gte: cutoffStr } } },
    { $group: { _id: '$member', lastVisit: { $max: '$date' }, visits: { $sum: 1 } } },
    { $lookup: { from: 'users', localField: '_id', foreignField: '_id', as: 'member' } },
    { $unwind: '$member' },
    {
      $project: {
        _id: 0,
        memberId: '$_id',
        name: '$member.name',
        email: '$member.email',
        lastVisit: 1,
        visits: 1,
      },
    },
    { $sort: { visits: -1 } },
  ]);
  res.json({ active: data });
};
