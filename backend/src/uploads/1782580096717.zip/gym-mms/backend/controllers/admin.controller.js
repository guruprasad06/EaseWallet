const User = require('../models/User');
const Membership = require('../models/Membership');

exports.listUsers = async (req, res) => {
  const { role } = req.query;
  const page = Math.max(1, parseInt(req.query.page) || 1);
  const limit = Math.min(100, parseInt(req.query.limit) || 20);
  const q = role ? { role } : {};
  const [users, total] = await Promise.all([
    User.find(q).select('-password -refreshTokens').skip((page - 1) * limit).limit(limit).sort({ createdAt: -1 }),
    User.countDocuments(q),
  ]);
  res.json({ users, total, page, pages: Math.ceil(total / limit) });
};

exports.toggleBlock = async (req, res) => {
  const u = await User.findById(req.params.id);
  if (!u) return res.status(404).json({ message: 'User not found' });
  u.isBlocked = !u.isBlocked;
  await u.save();
  res.json({ user: u.toSafeJSON() });
};

exports.assignTrainer = async (req, res) => {
  const { trainerId } = req.body;
  const member = await User.findById(req.params.id);
  const trainer = await User.findById(trainerId);
  if (!member || member.role !== 'member') return res.status(404).json({ message: 'Member not found' });
  if (!trainer || trainer.role !== 'trainer') return res.status(404).json({ message: 'Trainer not found' });
  member.assignedTrainer = trainer._id;
  await member.save();
  res.json({ user: member.toSafeJSON() });
};

exports.subscriptionsReport = async (req, res) => {
  const report = await Membership.aggregate([
    {
      $group: {
        _id: '$status',
        count: { $sum: 1 },
      },
    },
  ]);
  const revenue = await Membership.aggregate([
    { $unwind: '$history' },
    { $group: { _id: null, total: { $sum: '$history.amountPaid' } } },
  ]);
  res.json({ statusBreakdown: report, totalRevenue: revenue[0]?.total || 0 });
};
