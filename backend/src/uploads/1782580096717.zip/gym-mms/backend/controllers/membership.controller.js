const Membership = require('../models/Membership');
const Plan = require('../models/Plan');

function addDays(date, days) {
  const d = new Date(date);
  d.setDate(d.getDate() + days);
  return d;
}

exports.subscribe = async (req, res) => {
  const { planId } = req.body;
  const plan = await Plan.findById(planId);
  if (!plan || plan.status !== 'active') return res.status(404).json({ message: 'Plan not available' });

  let m = await Membership.findOne({ member: req.user._id });
  const now = new Date();
  const expiry = addDays(now, plan.durationDays);

  if (!m) {
    m = await Membership.create({
      member: req.user._id,
      plan: plan._id,
      startDate: now,
      expiryDate: expiry,
      status: 'active',
      history: [{ plan: plan._id, startDate: now, expiryDate: expiry, amountPaid: plan.price.amount }],
    });
  } else {
    m.plan = plan._id;
    m.startDate = now;
    m.expiryDate = expiry;
    m.status = 'active';
    m.history.push({ plan: plan._id, startDate: now, expiryDate: expiry, amountPaid: plan.price.amount });
    await m.save();
  }
  res.json({ membership: m });
};

exports.renew = async (req, res) => {
  const m = await Membership.findOne({ member: req.user._id }).populate('plan');
  if (!m) return res.status(404).json({ message: 'No membership to renew' });
  const base = m.expiryDate > new Date() ? m.expiryDate : new Date();
  const newExpiry = addDays(base, m.plan.durationDays);
  m.expiryDate = newExpiry;
  m.status = 'active';
  m.history.push({
    plan: m.plan._id,
    startDate: new Date(),
    expiryDate: newExpiry,
    amountPaid: m.plan.price.amount,
  });
  await m.save();
  res.json({ membership: m });
};

exports.mine = async (req, res) => {
  const m = await Membership.findOne({ member: req.user._id }).populate('plan');
  if (m && m.expiryDate < new Date() && m.status === 'active') {
    m.status = 'expired';
    await m.save();
  }
  res.json({ membership: m });
};
