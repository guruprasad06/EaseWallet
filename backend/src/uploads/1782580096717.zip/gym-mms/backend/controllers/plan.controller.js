const Plan = require('../models/Plan');

exports.list = async (req, res) => {
  const plans = await Plan.find({ status: 'active' }).sort({ 'price.amount': 1 });
  res.json({ plans });
};

exports.create = async (req, res) => {
  const plan = await Plan.create(req.body);
  res.status(201).json({ plan });
};

exports.update = async (req, res) => {
  const plan = await Plan.findByIdAndUpdate(req.params.id, req.body, { new: true });
  if (!plan) return res.status(404).json({ message: 'Plan not found' });
  res.json({ plan });
};

exports.remove = async (req, res) => {
  await Plan.findByIdAndDelete(req.params.id);
  res.json({ ok: true });
};
