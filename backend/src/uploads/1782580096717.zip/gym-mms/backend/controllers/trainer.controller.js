const User = require('../models/User');

exports.myMembers = async (req, res) => {
  const members = await User.find({ assignedTrainer: req.user._id, role: 'member' }).select('-password -refreshTokens');
  res.json({ members });
};
