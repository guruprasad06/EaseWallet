const Workout = require('../models/Workout');
const User = require('../models/User');

exports.create = async (req, res) => {
  const { memberId } = req.body;
  const member = await User.findById(memberId);
  if (!member || member.role !== 'member') return res.status(404).json({ message: 'Member not found' });
  // Trainer can only create workouts for assigned members (admin bypass)
  if (req.user.role === 'trainer' && String(member.assignedTrainer) !== String(req.user._id)) {
    return res.status(403).json({ message: 'Member not assigned to you' });
  }
  const w = await Workout.create({ ...req.body, member: memberId, trainer: req.user._id });
  res.status(201).json({ workout: w });
};

exports.update = async (req, res) => {
  const w = await Workout.findById(req.params.id);
  if (!w) return res.status(404).json({ message: 'Not found' });
  if (req.user.role === 'trainer' && String(w.trainer) !== String(req.user._id)) {
    return res.status(403).json({ message: 'Forbidden' });
  }
  Object.assign(w, req.body);
  await w.save();
  res.json({ workout: w });
};

exports.mine = async (req, res) => {
  const workouts = await Workout.find({ member: req.user._id }).populate('trainer', 'name email');
  res.json({ workouts });
};

exports.forMember = async (req, res) => {
  const workouts = await Workout.find({ member: req.params.memberId }).populate('trainer', 'name email');
  res.json({ workouts });
};
