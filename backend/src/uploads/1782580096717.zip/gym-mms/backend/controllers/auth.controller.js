const User = require('../models/User');
const { signAccess, signRefresh, verifyRefresh } = require('../utils/jwt');

exports.register = async (req, res) => {
  const { name, email, password, role, phone } = req.body;
  const exists = await User.findOne({ email });
  if (exists) return res.status(409).json({ message: 'Email already in use' });
  // Only allow admin role assignment if no admins exist or done via admin endpoint
  let finalRole = role || 'member';
  if (finalRole === 'admin') {
    const adminCount = await User.countDocuments({ role: 'admin' });
    if (adminCount > 0) finalRole = 'member';
  }
  const user = await User.create({ name, email, password, role: finalRole, phone });
  res.status(201).json({ user: user.toSafeJSON() });
};

exports.login = async (req, res) => {
  const { email, password } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(401).json({ message: 'Invalid credentials' });
  if (user.isBlocked) return res.status(403).json({ message: 'Account blocked' });
  const ok = await user.comparePassword(password);
  if (!ok) return res.status(401).json({ message: 'Invalid credentials' });

  const payload = { id: user._id.toString(), role: user.role };
  const accessToken = signAccess(payload);
  const refreshToken = signRefresh(payload);
  user.refreshTokens.push(refreshToken);
  await user.save();
  res.json({ accessToken, refreshToken, user: user.toSafeJSON() });
};

exports.refresh = async (req, res) => {
  const { refreshToken } = req.body;
  if (!refreshToken) return res.status(400).json({ message: 'refreshToken required' });
  try {
    const decoded = verifyRefresh(refreshToken);
    const user = await User.findById(decoded.id);
    if (!user || !user.refreshTokens.includes(refreshToken)) {
      return res.status(401).json({ message: 'Invalid refresh token' });
    }
    const accessToken = signAccess({ id: user._id.toString(), role: user.role });
    res.json({ accessToken });
  } catch {
    res.status(401).json({ message: 'Invalid refresh token' });
  }
};

exports.logout = async (req, res) => {
  const { refreshToken } = req.body;
  if (refreshToken) {
    await User.updateOne({ refreshTokens: refreshToken }, { $pull: { refreshTokens: refreshToken } });
  }
  res.json({ ok: true });
};

exports.me = async (req, res) => {
  res.json({ user: req.user.toSafeJSON() });
};
