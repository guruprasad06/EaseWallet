require('dotenv').config();
const connectDB = require('../config/db');
const User = require('../models/User');
const Plan = require('../models/Plan');

(async () => {
  await connectDB();
  const adminEmail = 'admin@gym.com';
  let admin = await User.findOne({ email: adminEmail });
  if (!admin) {
    admin = await User.create({
      name: 'Admin',
      email: adminEmail,
      password: 'Admin@123',
      role: 'admin',
    });
    console.log('Created admin:', adminEmail, '/ Admin@123');
  }
  const count = await Plan.countDocuments();
  if (count === 0) {
    await Plan.insertMany([
      { name: 'Monthly', price: { amount: 999, currency: 'INR' }, durationDays: 30, features: ['Gym access', 'Locker'] },
      { name: 'Quarterly', price: { amount: 2499, currency: 'INR' }, durationDays: 90, features: ['Gym access', 'Locker', '1 PT session'] },
      { name: 'Yearly', price: { amount: 8999, currency: 'INR' }, durationDays: 365, features: ['Gym access', 'Locker', '4 PT sessions', 'Nutrition plan'] },
    ]);
    console.log('Seeded plans');
  }
  process.exit(0);
})();
