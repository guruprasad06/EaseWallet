const mongoose = require('mongoose');

const membershipSchema = new mongoose.Schema(
  {
    member: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    plan: { type: mongoose.Schema.Types.ObjectId, ref: 'Plan', required: true },
    startDate: { type: Date, default: Date.now },
    expiryDate: { type: Date, required: true, index: true },
    status: { type: String, enum: ['active', 'expired', 'cancelled'], default: 'active', index: true },
    history: [
      {
        plan: { type: mongoose.Schema.Types.ObjectId, ref: 'Plan' },
        startDate: Date,
        expiryDate: Date,
        amountPaid: Number,
      },
    ],
  },
  { timestamps: true }
);

membershipSchema.methods.isActive = function () {
  return this.status === 'active' && this.expiryDate > new Date();
};

module.exports = mongoose.model('Membership', membershipSchema);
