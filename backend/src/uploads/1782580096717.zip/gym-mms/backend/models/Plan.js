const mongoose = require('mongoose');

const planSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, unique: true },
    price: {
      amount: { type: Number, required: true },
      currency: { type: String, default: 'INR' },
    },
    durationDays: { type: Number, required: true },
    features: [{ type: String }],
    status: { type: String, enum: ['active', 'inactive'], default: 'active' },
  },
  { timestamps: true }
);

module.exports = mongoose.model('Plan', planSchema);
