const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, index: true },
    password: { type: String, required: true },
    role: { type: String, enum: ['admin', 'trainer', 'member'], default: 'member', index: true },
    phone: { type: String },
    isBlocked: { type: Boolean, default: false },
    assignedTrainer: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    refreshTokens: [{ type: String }],
  },
  { timestamps: true }
);

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

userSchema.methods.comparePassword = function (pw) {
  return bcrypt.compare(pw, this.password);
};

userSchema.methods.toSafeJSON = function () {
  const { _id, name, email, role, phone, isBlocked, assignedTrainer, createdAt } = this;
  return { id: _id, name, email, role, phone, isBlocked, assignedTrainer, createdAt };
};

module.exports = mongoose.model('User', userSchema);
