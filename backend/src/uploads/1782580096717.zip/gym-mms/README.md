# Gym Membership Management System

Fullstack project: **Node.js + Express + MongoDB** backend with JWT auth, role-based access, memberships, trainers, workouts, attendance, and admin reports. **React (Vite)** frontend with a simple, clean UI.

## Project Structure

```
gym-mms/
├── backend/      # Node.js + Express + MongoDB API
└── frontend/     # React (Vite) client
```

## Backend Setup

```bash
cd backend
npm install
cp .env.example .env   # fill MONGO_URI, JWT secrets
npm run seed           # optional: create default admin + plans
npm run dev
```

Server runs on `http://localhost:5000`.

### Default seeded admin
- email: `admin@gym.com`
- password: `Admin@123`

### API Base
`http://localhost:5000/api`

#### Auth
- `POST /auth/register` `{ name, email, password, role? }`
- `POST /auth/login` `{ email, password }` → `{ accessToken, refreshToken, user }`
- `POST /auth/refresh` `{ refreshToken }`
- `POST /auth/logout`

#### Membership
- `GET  /plans` (public)
- `POST /plans` (admin)
- `POST /memberships/subscribe` `{ planId }` (member)
- `POST /memberships/renew` (member)
- `GET  /memberships/me` (member)

#### Trainer / Workout
- `GET  /trainers/members` (trainer) – assigned members
- `POST /workouts` (trainer) `{ memberId, exercises[], schedule{}, difficulty }`
- `PUT  /workouts/:id` (trainer)
- `GET  /workouts/me` (member)

#### Attendance
- `POST /attendance/checkin` (member)
- `POST /attendance/checkout` (member)
- `GET  /attendance/me` (member, paginated)
- `GET  /attendance/report/monthly?month=&year=` (admin/trainer)
- `GET  /attendance/active` (admin)

#### Admin
- `GET    /admin/users?role=&page=&limit=` (admin)
- `PATCH  /admin/users/:id/block` (admin)
- `PATCH  /admin/users/:id/assign-trainer` `{ trainerId }` (admin)
- `GET    /admin/reports/subscriptions` (admin)

## Frontend Setup

```bash
cd frontend
npm install
npm run dev
```

Runs on `http://localhost:5173`. Configure backend URL in `frontend/.env` (`VITE_API_URL`).

## Tech
- **Backend:** Node.js, Express, MongoDB + Mongoose, JWT (access + refresh), bcrypt, Joi, helmet, cors, morgan
- **Frontend:** React 18, Vite, React Router, Axios
- **Security:** JWT auth, role-based middleware, password hashing, input validation, protected routes, indexed schemas, aggregation pipelines for reports, pagination
